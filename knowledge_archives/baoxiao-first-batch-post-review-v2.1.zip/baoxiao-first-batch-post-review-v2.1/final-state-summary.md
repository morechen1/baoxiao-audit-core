# 首批非处罚资料审核后状态

- 代码基线：`develop 339c7dc6589313ca804d0abe0bd62f6eebb60819`
- 正式审核包 V2 SHA-256：`f50eefc2f30fcd1d7fa533f98fa19157ef355cbb076caafb663e3050e8c58456`
- 文档：20；结构化记录：32
- 直接批准：5；带修订批准：5
- ReviewDecision：10；AuthenticityDecision：10
- `verified_public`：10
- 索引准入：5（REG-001、REG-002、REG-003、PROD-001、PROD-002）
- 案例：5 份均保持 `external_test_candidate`，未索引
- 处罚：10 份均保持 `requires_expert_review`、`pending_verification`、`not_indexed`
- 字段证据：原 182 项，新增 10 项合法证据，最终 192 项
- 实际修订：13 条结构化记录、14 个字段
- 原件与解析产物：20/20 哈希复核通过
- 审核批次：法规、案例、产品均为 `completed`；处罚保持 `exported`

`index-approved` 只表示可信索引载荷准入；当前尚未实现 BM25、向量检索或 RAG。
