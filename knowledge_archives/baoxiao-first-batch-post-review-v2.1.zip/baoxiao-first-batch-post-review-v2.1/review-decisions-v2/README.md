# 正式审核决定 V2

本目录包含当前一次性 PostgreSQL 数据库导出的三类正式决定文件：

- `regulations-review-results.jsonl`：3 份法规
- `regulatory-cases-review-results.jsonl`：5 份监管案例
- `product-documents-review-results.jsonl`：2 份产品资料

每条决定绑定当前数据库的 `document_id`、`pilot_id`、V2 payload hash、来源
occurrence、审核人和（如适用）portable_record_key corrections。处罚资料不在本目录。
