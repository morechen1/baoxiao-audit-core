# Final State Summary

- SourceDocument: 10
- Penalty: 34
- FieldEvidence: 177
- ReviewDecision: 10
- AuthenticityDecision: 10
- verified_public: 10
- approved: 4
- approved_with_revision: 6
- Controlled document-number corrections: 20
- indexed documents: 10
- index-admitted Penalty payloads: 34
