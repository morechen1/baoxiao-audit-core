# 保销智审：首批 20 项结构化草稿与人工审核包 V2

本包由同一批已经独立验收的 20 份不可变公开原件离线恢复生成。未访问网络，
未重新采集，未改写原件，未应用审核决定，未升级真实性，也未执行索引。

## 可移植性

`portability-verification/` 保存 PostgreSQL 16 数据库 A、数据库 B 的逐 Pilot
payload hash 与比较报告。数据库 B 的 SourceDocument 自增序列被有意偏移，
20 个数据库 ID 均与 A 不同；V2 payload hash、portable_record_key 和解析产物
SHA-256 仍逐项一致。

## 审核材料

四类审核材料位于 `review-bundles/`。每类目录同时包含正式 ZIP 和解压内容；
`manifest.json`、`review.jsonl` 和结果模板均声明
`review_payload_schema_version: 2`。所有结构化记录均包含稳定
`portable_record_key`。

## 数据边界

业务数据保持 32 条结构化记录和 182 项字段证据。REG-001 与 REG-002 的既有
字段值未在本轮擅自补写；新证据能力及真实材料定位示例单独保存在验证报告中。
本包不包含 PostgreSQL 数据目录、数据库口令、Token、Cookie、索引或真实审核决定。
