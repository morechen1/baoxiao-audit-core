# 首批 20 项结构化草稿审核总览 V2

- Portable Review Payload Schema：2
- PostgreSQL 16 数据库 A/B：20/20 payload hash 完全一致
- 两库 SourceDocument ID：20/20 全部不同
- portable_record_key：20/20 文档内记录集合一致
- parsed artifact SHA-256：20/20 一致
- SourceDocument：20
- 结构化记录：32（法规 15、处罚 10、监管案例 5、产品 2）
- 字段证据：182
- pending_verification：20
- ReviewDecision：0
- AuthenticityDecision：0
- indexed：0
- requires_expert_review：10（多主体处罚）

V2 不自动兼容 V1。审核决定必须携带
`review_payload_schema_version: 2`，修订记录使用 `portable_record_key` 定位。
REG-001 多行日期和 REG-002 `nfra.caption` 的真实材料示例见
`validation-reports/evidence-boundary-examples.json`。
