# 保销智审首批真实公开数据试采集 V1 成功材料包

本包合并两次相互独立且均经过哈希核验的正式采集结果：

- 18 份 NFRA 资料：GitHub Hosted Ubuntu、无代理、真实公网 DNS、全新 PostgreSQL 16，通过官方同域公开 JSON 接口采集并解析；
- 2 份 CPIC 产品 PDF：保留自上一轮已经成功的官方 PDF 原件和解析产物，未重新请求。

总计 20 项，全部原件及解析产物哈希一致，全部保持 `pending_verification`，未执行结构化导入、人工审核、真实性升级或索引。NFRA 数据库快照作为 Hosted Runner artifact 的独立文件保留，不包含在本 ZIP。
