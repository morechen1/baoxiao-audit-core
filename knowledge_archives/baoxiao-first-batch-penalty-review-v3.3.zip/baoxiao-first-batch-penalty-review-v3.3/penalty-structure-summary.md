# Penalty review structure summary V3.3

- Source documents: 10
- Penalty records: 34
- Field evidence items: 177
- Payload hashes across fresh databases: 10/10
- Content hashes, fingerprints and portable keys: 34/34 each
- Punished entity and illegal facts in fixed identity: 34/34 each
- Penalty result identity coverage: 34/34
- Document number identity coverage: 31/31
- Unrelated identity fragments: 0
- Subject-only identities: 0
- Exact identity evidence: 34/34
- Position-ordered, non-overlapping identity fragments: 34/34
- Review and authenticity decisions: 0
- Indexed: 0
- All documents remain requires_expert_review, pending_verification, and not_indexed
